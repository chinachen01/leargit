package com.xlythe.math;

public class SpellException extends Exception {
    private static final long serialVersionUID = 1L;

    public SpellException(String message) {
        super(message);
    }
}
