package com.android.calculator2.view.display;

public interface AdvancedDisplayControls {
    public boolean hasNext();
}
